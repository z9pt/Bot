import logging
import os
import json
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.constants import ParseMode
from telegram.ext import CallbackContext
import config
import traceback

logger = logging.getLogger(__name__)
translations = {}

def load_translations():
    """Load translations from a JSON file and store them in the global variable."""
    global translations  # Use the global variable
    if not os.path.exists("translations.json"):
        logger.warning("'translations.json' file not found. Returning empty dictionary.")
        translations = {}  # Empty dictionary if file doesn't exist
        return
    
    try:
        with open("translations.json", "r", encoding="utf-8") as file:
            content = file.read().strip()
            if not content:  # If the content is empty
                logger.warning("'translations.json' is empty. Returning empty dictionary.")
                translations = {}
                return
            translations = json.loads(content)  # Store the parsed content in the global variable
    except json.JSONDecodeError:
        logger.error("Malformed JSON in 'translations.json'. Returning empty dictionary.")
        translations = {}
    except Exception as e:
        logger.error(f"Failed to load translations due to: {str(e)}. Returning empty dictionary.")
        translations = {}

def translate(key, language_code="en"):
    """Translate text based on the provided key and language code."""
    # Ensure translations are loaded only once
    if not translations:
        load_translations()  # Load translations if not already loaded
    
    # Fallback to key if translation is missing
    return translations.get(language_code, {}).get(key, key)

def load_posts():
    if not os.path.exists("posts.json"):
        return {}  # File doesn't exist, return empty dictionary
    with open("posts.json", "r") as file:
        content = file.read().strip()  # Read and strip any leading/trailing whitespace
        if not content:  # If the content is empty
            return {}
        try:
            return json.loads(content)  # Attempt to parse the JSON content
        except json.JSONDecodeError:
            print("Error: Malformed JSON in 'posts.json'. Returning empty dictionary.")
            return {}
posts = load_posts()
def save_posts(posts):
    with open("posts.json", "w") as file:
        json.dump(posts, file, indent=4)


async def mark_as_sold(update: Update, context: CallbackContext) -> None:
    posts = load_posts()
    user_language = context.user_data.get('language', 'en')

    # Ensure the command is sent in reply to a post
    if not update.message.reply_to_message:
        await update.message.reply_text(translate("please_reply_to_post", language_code=user_language))
        return

    # Get original post details
    message_id = str(update.message.reply_to_message.message_id)
    user_id = update.message.from_user.id
    # Check if the post exists and the user is the owner
    if message_id not in posts:
        await update.message.reply_text(translate("post_not_registered", language_code=user_language))
        return

    post = posts[message_id]
    
    # Check if the user is the owner of the post
    if post["owner_id"] != user_id:
        await update.message.reply_text("You are not the owner of this post.")
        return

    # Check if the post is already marked as sold
    if post.get("status") == "Sold":
        await update.message.reply_text(translate("post_already_sold", language_code=user_language))
        return

    # Prepare the new message text (same as the original message)
    new_message_text = update.message.reply_to_message.text
    print(new_message_text)

    # Split the message text by lines
    message_lines = new_message_text.split("\n")
    
    # Modify the second line (username line) if it exists
    if len(message_lines) > 1:
        message_lines[1] = f"<blockquote><code>{message_lines[1]}</code></blockquote>"
        new_message_text = "\n".join(message_lines)
    
    try:
        # Edit the channel message to update only the button (keep text the same)
        await context.bot.edit_message_text(
            chat_id=post["channel_id"],  # Use numeric channel_id
            message_id=post["message_id"],
            text=new_message_text,  # Keep the text as it is with the updated second line
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Sold",callback_data="sold")]  # Changed callback data here
            ])
        )
        
        # Mark the post as sold
        post["status"] = "Sold"
        save_posts(posts)

    except Exception as e:
        print(f"Error editing message: {e}")
        await update.message.reply_text("Failed to update the channel message.")
        traceback.print_exc()
        return

    # Notify the owner
    await update.message.reply_text(translate("mark_as_sold", language_code=user_language))


def parse_message(message: str):
    lines = message.split('\n')
    platform_name = lines[0].strip()
    username = lines[1].strip()
    price = lines[2].strip() if len(lines) > 2 else ""
    description = lines[3].strip() if len(lines) > 3 else ""
    
    # Validate format for platform name and username
    if not validate_platform_name(platform_name) or not validate_username(username):
        return None, None, None, None
    
    return platform_name, username, price, description
async def register_post(update: Update, context: CallbackContext, sent_message_id: int):
    # Get the user's message_id (this is the message they sent)
    message_id = str(update.message.message_id)  # User's message ID, not the bot's
    user_id = update.message.from_user.id

    # Get channel ID (numeric)
    channel_username = config.CHANNEL_USERNAME  # Example username, replace with dynamic if needed
    chat = await context.bot.get_chat(channel_username)
    channel_id = chat.id  # Numeric channel ID

    # Create the post dictionary with message_id, owner_id, and channel_id
    post = {
        "owner_id": user_id,
        "message_id": sent_message_id,  # Save the bot's sent message_id
        "channel_id": str(channel_id),  # Save the numeric channel ID
    }

    # Load existing posts
    posts = load_posts()

    # Check if the post with the same message_id already exists
    if message_id not in posts:
        # If no existing post with the same message_id, add the new post
        posts[message_id] = post
        print(f"New post registered with message_id {message_id} and channel_id {channel_id}")
    else:
        print(f"Post with message_id {message_id} already exists. Skipping.")

    # Save the updated posts back to the file
    save_posts(posts)

def load_trusted_users(filename="trusted_users.txt"):
    """Load trusted users from the specified file."""
    trusted_users = set()
    try:
        with open(filename, "r") as file:
            trusted_users = {int(line.strip()) for line in file if line.strip().isdigit()}
        logger.info(f"Loaded {len(trusted_users)} trusted users.")
    except Exception as e:
        logger.error(f"Error loading trusted users: {e}")
    return trusted_users


def load_trusted_admins(filename="trusted_admins.txt"):
    """Load trusted admins from the specified file."""
    trusted_admins = set()
    try:
        with open(filename, "r") as file:
            trusted_admins = {int(line.strip()) for line in file if line.strip().isdigit()}
        logger.info(f"Loaded {len(trusted_admins)} trusted admins.")
    except Exception as e:
        logger.error(f"Error loading trusted admins: {e}")
    return trusted_admins


def load_banned_users(filename="banned_users.txt"):
    """Load banned users from the specified file."""
    banned_users = set()
    try:
        with open(filename, "r") as file:
            banned_users = {int(line.strip()) for line in file if line.strip().isdigit()}
        logger.info(f"Loaded {len(banned_users)} banned users.")
    except Exception as e:
        logger.error(f"Error loading banned users: {e}")
    return banned_users


def save_trusted_users(trusted_users, filename="trusted_users.txt"):
    """Save trusted users to the specified file."""
    try:
        with open(filename, "w") as file:
            for user in trusted_users:
                file.write(f"{user}\n")
        logger.info(f"Saved {len(trusted_users)} trusted users.")
    except Exception as e:
        logger.error(f"Error saving trusted users: {e}")


def save_trusted_admins(trusted_admins, filename="trusted_admins.txt"):
    """Save trusted admins to the specified file."""
    try:
        with open(filename, "w") as file:
            for admin in trusted_admins:
                file.write(f"{admin}\n")
        logger.info(f"Saved {len(trusted_admins)} trusted admins.")
    except Exception as e:
        logger.error(f"Error saving trusted admins: {e}")


def save_banned_users(banned_users, filename="banned_users.txt"):
    """Save banned users to the specified file."""
    try:
        with open(filename, "w") as file:
            for user in banned_users:
                file.write(f"{user}\n")
        logger.info(f"Saved {len(banned_users)} banned users.")
    except Exception as e:
        logger.error(f"Error saving banned users: {e}")
