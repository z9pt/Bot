
import re
DOMAIN_REGEX = r"([A-Za-z0-9-]+\.[A-Za-z0-9-]{2,})"

def validate_platform_name(platform_name: str) -> bool:
    # Platform name should not contain URLs or domain-like structures
    if re.search(DOMAIN_REGEX, platform_name):
        return False
    return bool(re.match(r"^[A-Za-z0-9\s._-ء-ي\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+$", platform_name))

def validate_username(username: str) -> bool:
    return bool(re.match(r"^@[A-Za-z0-9._-]{1,32}$", username))

def validate_price(price: str) -> bool:
    # Price should not contain domain-like structures
    if re.search(DOMAIN_REGEX, price):
        return False
    return bool(re.match(r"^[^\@]{0,20}$", price))

def validate_description(description: str) -> bool:
    # Description should not contain domain-like structures
    if re.search(DOMAIN_REGEX, description):
        return False
    return bool(re.match(r"^[A-Za-z0-9\s._-ء-ي\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+$", description))

# Modify the validate_message function to handle empty price and description
def validate_message(message_text: str) -> tuple:
    lines = message_text.strip().split('\n')
    if len(lines) < 2 or len(lines) > 4:
        return False, "Invalid number of lines in the message."
    
    platform_name = lines[0].strip()
    username = lines[1].strip()
    price = lines[2].strip() if len(lines) > 2 else ""
    description = lines[3].strip() if len(lines) > 3 else ""

    # Validate each field
    if not validate_platform_name(platform_name):
        return False, "Invalid platform name. It should only contain letters, numbers, spaces, periods, underscores, or hyphens and be no longer than 60 characters. Domain names are not allowed."
    
    if not validate_username(username):
        return False, "Invalid username format. The username must start with '@' followed by letters, numbers, periods, hyphens, underscores, or domain-style periods (max 32 characters)."

    if price and not validate_price(price):
        return False, "Invalid price format. It must be no longer than 20 characters and not contain '@' or domain names."
    
    if description and not validate_description(description):
        return False, "Description should be at most 60 characters long and must not contain '@' or domain names."

    return True, (platform_name, username, price, description)
