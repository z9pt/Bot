# config.py

import json

def load_config(file_path):
    """Function to load configuration from a JSON file"""
    with open(file_path, 'r') as file:
        config = json.load(file)
    return config

# Load the configuration from the JSON file
config = load_config('config.json')

# Set the variables based on the loaded config
BOT_TOKEN = config.get('BOT_TOKEN')
CHANNEL_USERNAME = config.get('CHANNEL_USERNAME')
