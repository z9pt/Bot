import re
import json
import os
import logging
from datetime import datetime, timedelta
import asyncio
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext
from telegram.constants import ParseMode
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
import config
import helpers 
from helpers import load_posts, save_posts, mark_as_sold, register_post, parse_message,translate
from validator import *

# Bot constants
BOT_TOKEN = config.BOT_TOKEN
CHANNEL_USERNAME = config.CHANNEL_USERNAME

# Load trusted and banned users
trusted_users = helpers.load_trusted_users()
trusted_admins = helpers.load_trusted_admins()
banned_users = helpers.load_banned_users()

# Logging setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# User cooldown tracking
user_last_submission = {}
COOLDOWN_DURATION = timedelta(minutes=2)
# Command to list all admins
async def list_admins(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to view the list of admins.")
        return

    # Prepare the list of admin IDs
    if trusted_admins:
        admins_list = "\n".join([str(admin_id) for admin_id in trusted_admins])
        await update.message.reply_text(f"List of admin IDs:\n{admins_list}")
    else:
        await update.message.reply_text("No admins found.")

async def add_trusted(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to add trusted users.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to add as a trusted user.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Add the user to the trusted users set
        if target_user_id not in trusted_users:
            trusted_users.add(target_user_id)
            helpers.save_trusted_users(trusted_users)  # Save changes to file
            await update.message.reply_text(f"User with ID {target_user_id} has been added as a trusted user.")
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is already a trusted user.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")
async def list_trusted(update: Update, context: CallbackContext) -> None:
    if update.message.from_user.id not in trusted_admins:
        await update.message.reply_text("You do not have permission to view trusted users.")
        return

    # Provide the count of trusted users
    count = len(trusted_users)
    await update.message.reply_text(f"There are {count} trusted users.")

async def add_admin(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to add admins.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to add as admin.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Add the user to the trusted admins set
        if target_user_id not in trusted_admins:
            trusted_admins.add(target_user_id)
            helpers.save_trusted_admins(trusted_admins)  # Save changes to file
            await update.message.reply_text(f"User with ID {target_user_id} has been added as an admin.")
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is already an admin.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")
async def delete_trusted(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to delete trusted users.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to delete from trusted users.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Remove the user from the trusted users set
        if target_user_id in trusted_users:
            trusted_users.remove(target_user_id)
            helpers.save_trusted_users(trusted_users)  # Save changes to file
            await update.message.reply_text(f"User with ID {target_user_id} has been removed from trusted users.")
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is not a trusted user.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")
# Delete admin command handler
async def delete_admin(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to delete admins.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to delete from admin.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Remove the user from the trusted admins set
        if target_user_id in trusted_admins:
            trusted_admins.remove(target_user_id)
            helpers.save_trusted_admins(trusted_admins)  # Save changes to file
            await update.message.reply_text(f"User with ID {target_user_id} has been removed from admin.")
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is not an admin.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")

async def whoami(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    user_username = update.message.from_user.username

    # Check if the user is trusted
    trusted_user = is_user_trusted(user_id)
    
    # Check if the user is an admin
    admin_status = "Yes" if user_id in trusted_admins else "No"
    
    # Check if the user is banned
    if user_id in banned_users:
        banned_status = "You are banned from using this bot."
    else:
        banned_status = "You are not banned."
    
    # Create the response message
    response = f"Your user ID: {user_id}\nYour username: @{user_username}\nTrusted: {'Yes' if trusted_user else 'No'}\nAdmin: {admin_status}\n{banned_status}"

    # Send the response to the user
    await update.message.reply_text(response)


# Example: Check if a user is trusted
async def istrusted(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to check trusted users.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to check if they are trusted.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Check if the user is trusted
        if target_user_id in trusted_users:
            await update.message.reply_text(f"User with ID {target_user_id} is trusted.")
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is not trusted.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")

# Command to check if a user is an admin
async def isadmin(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to check admins.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to check if they are an admin.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Check if the user is an admin
        if target_user_id in trusted_admins:
            await update.message.reply_text(f"User with ID {target_user_id} is an admin.")
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is not an admin.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")
def is_user_trusted(user_id: int) -> bool:
    return user_id in trusted_users

    
async def start(update: Update, context: CallbackContext) -> None:
    user_language = context.user_data.get('language', 'en')
    
    try:
        # The message instructing the user how to change language and list commands
        language_message = (
            "You can change the language by sending /language.\n"
            "يمكنك تغيير اللغة عن طريق إرسال /language.\n\n"
            "To view available commands, use /commands.\n"
            "لعرض الأوامر المتاحة، استخدم /commands.\n\n"
        )

        # First, send the language change instruction and commands message
        await update.message.reply_text(language_message)

        # Then send the message format based on the user's selected language
        await update.message.reply_text(
            translate("send_message_format", language_code=user_language), parse_mode=ParseMode.HTML
        )
        
    except Exception as e:
        logger.error(f"Error in start handler: {e}")


async def check_subscription(update: Update, context: CallbackContext) -> bool:
    try:
        await asyncio.sleep(0.30)  # 0.3-second delay to process subscription
        member = await context.bot.get_chat_member(CHANNEL_USERNAME, update.message.from_user.id)
        
        if member.status in ['member', 'administrator', 'creator']:
            return True
        else:
            return False
        
    except Exception as e:
        logger.error(f"Error checking subscription: {e}")
        return False


async def check_banned(update: Update, context: CallbackContext) -> bool:
    user_language = context.user_data.get('language', 'en')
    user_id = update.message.from_user.id

    if user_id in banned_users:
        await update.message.reply_text(translate("banned_message", language_code=user_language))
        return False
    return True


# Ban command handler
async def ban(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to ban users.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to ban.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument
        if target_user_id in banned_users:
            await update.message.reply_text(f"User with ID {target_user_id} is already banned.")
            return
        # Ban the user by adding them to the banned set
        banned_users.add(target_user_id)
        helpers.save_banned_users(banned_users)
        await update.message.reply_text(f"User with ID {target_user_id} has been banned.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")

# Unban command handler
async def unban(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id

    # Check if the user is an admin
    if user_id not in trusted_admins:
        await update.message.reply_text("You do not have permission to unban users.")
        return

    if not context.args:
        await update.message.reply_text("Please provide a user ID to unban.")
        return

    try:
        target_user_id = int(context.args[0])  # Assuming the user ID is passed as an argument

        # Unban the user by removing them from the banned set
        if target_user_id in banned_users:
            banned_users.remove(target_user_id)
            helpers.save_banned_users(banned_users)
            await update.message.reply_text(f"User with ID {target_user_id} has been unbanned.")
            
        else:
            await update.message.reply_text(f"User with ID {target_user_id} is not banned.")
    except ValueError:
        await update.message.reply_text("Invalid user ID provided.")

async def list_commands(update: Update, context: CallbackContext) -> None:
    # Retrieve the user's preferred language from context, default to 'en'
    user_language = context.user_data.get('language', 'en')
    user_id = update.message.from_user.id
    is_admin = user_id in trusted_admins
    commands_user = {
        "en": (
            "<blockquote><code>/start</code></blockquote> - Get started with the bot and instructions.\n"
            "<blockquote><code>/whoami</code></blockquote> - Get your user info.\n"
            "<blockquote><code>/commands</code></blockquote> - List available commands.\n"
            "<blockquote><code>/language</code></blockquote> - Change the bot language.\n"
            "<blockquote><code>/sold</code></blockquote> - Mark a post as sold.\n"
        ),
        "ar": (
            "<blockquote><code>/start</code></blockquote> - ابدأ مع البوت و التعليمات.\n"
            "<blockquote><code>/whoami</code></blockquote> - احصل على معلومات المستخدم الخاصة بك.\n"
            "<blockquote><code>/commands</code></blockquote> - عرض الأوامر المتاحة.\n"
            "<blockquote><code>/language</code></blockquote> - تغيير لغة البوت.\n"
            "<blockquote><code>/sold</code></blockquote> - وضع علامة على المنشور كتم بيعه.\n"
        ),
    }

    # Commands for admin users
    commands_admin = {
        "en": (
            "<blockquote><code>/start</code></blockquote> - Get started with the bot and instructions.\n"
            "<blockquote><code>/language</code></blockquote> - Change the bot language.\n"
            "<blockquote><code>/whoami</code></blockquote> - Get your user info.\n"
            "<blockquote><code>/commands</code></blockquote> - List available commands.\n"
            "<blockquote><code>/addtrusted &lt;user_id&gt;</code></blockquote> - Add a user to the trusted list (admin only).\n"
            "<blockquote><code>/deletetrusted &lt;user_id&gt;</code></blockquote> - Remove a user from the trusted list (admin only).\n"
            "<blockquote><code>/addadmin &lt;user_id&gt;</code></blockquote> - Add a user to the admin list (admin only).\n"
            "<blockquote><code>/deleteadmin &lt;user_id&gt;</code></blockquote> - Remove a user from the admin list (admin only).\n"
            "<blockquote><code>/listtrusted</code></blockquote> - List all trusted users (admin only).\n"
            "<blockquote><code>/ban &lt;user_id&gt;</code></blockquote> - Ban a user (admin only).\n"
            "<blockquote><code>/unban &lt;user_id&gt;</code></blockquote> - Unban a user (admin only).\n"
            "<blockquote><code>/istrusted &lt;user_id&gt;</code></blockquote> - Check if a user is trusted (admin only).\n"
            "<blockquote><code>/isadmin &lt;user_id&gt;</code></blockquote> - Check if a user is an admin (admin only).\n"
            "<blockquote><code>/sold</code></blockquote> - Mark a post as sold (only for post owners).\n"
            "<blockquote><code>/listadmins</code></blockquote> - List all admin users (admin only).\n"
        ),
        "ar": (
            "<blockquote><code>/start</code></blockquote> - ابدأ مع البوت و التعليمات.\n"
             "<blockquote><code>/language</code></blockquote> - تغيير لغة البوت.\n"
            "<blockquote><code>/whoami</code></blockquote> - احصل على معلومات المستخدم الخاصة بك.\n"
            "<blockquote><code>/commands</code></blockquote> - عرض الأوامر المتاحة.\n"
            "<blockquote><code>/addtrusted &lt;user_id&gt;</code></blockquote> - إضافة مستخدم إلى قائمة المستخدمين الموثوقين (للأدمن فقط).\n"
            "<blockquote><code>/deletetrusted &lt;user_id&gt;</code></blockquote> - إزالة مستخدم من قائمة المستخدمين الموثوقين (للأدمن فقط).\n"
            "<blockquote><code>/addadmin &lt;user_id&gt;</code></blockquote> - إضافة مستخدم إلى قائمة الأدمن (للأدمن فقط).\n"
            "<blockquote><code>/deleteadmin &lt;user_id&gt;</code></blockquote> - إزالة مستخدم من قائمة الأدمن (للأدمن فقط).\n"
            "<blockquote><code>/listtrusted</code></blockquote> - عرض قائمة بجميع المستخدمين الموثوقين (للأدمن فقط).\n"
            "<blockquote><code>/ban &lt;user_id&gt;</code></blockquote> - حظر مستخدم (للأدمن فقط).\n"
            "<blockquote><code>/unban &lt;user_id&gt;</code></blockquote> - فك حظر مستخدم (للأدمن فقط).\n"
            "<blockquote><code>/istrusted &lt;user_id&gt;</code></blockquote> - التحقق إذا كان المستخدم موثوقًا (للأدمن فقط).\n"
            "<blockquote><code>/isadmin &lt;user_id&gt;</code></blockquote> - التحقق إذا كان المستخدم أدمن (للأدمن فقط).\n"
            "<blockquote><code>/sold</code></blockquote> - وضع علامة على المنشور كتم بيعه (لأصحاب المنشورات فقط).\n"
            "<blockquote><code>/listadmins</code></blockquote> - عرض جميع مستخدمي الأدمن (للأدمن فقط).\n"
        ),
    }

    # Send appropriate commands based on whether the user is an admin
    if is_admin:
        # Admin commands
        await update.message.reply_text(commands_admin.get(user_language, commands_admin["en"]), parse_mode="HTML")
    else:
        # User commands
        await update.message.reply_text(commands_user.get(user_language, commands_user["en"]), parse_mode="HTML")



