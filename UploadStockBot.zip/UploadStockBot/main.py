import re,json,os
import logging
from datetime import datetime, timedelta
import asyncio
from telegram import Update
import traceback
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext,CallbackQueryHandler
from telegram.constants import ParseMode
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
import config
import helpers 
from helpers import load_posts, save_posts, mark_as_sold, register_post, parse_message,translate
from validator import *
from commands import *
BOT_TOKEN = config.BOT_TOKEN
CHANNEL_USERNAME = config.CHANNEL_USERNAME
trusted_users = helpers.load_trusted_users()
trusted_admins = helpers.load_trusted_admins()
banned_users = helpers.load_banned_users()
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)
user_last_submission = {}
COOLDOWN_DURATION = timedelta(minutes=2)
helpers.load_translations()

async def handle_message(update: Update, context: CallbackContext) -> None:
    user_language = context.user_data.get('language', 'en')
    posts = load_posts()
    try:
        user_id = update.message.from_user.id

        # Check if the user is banned
        if not await check_banned(update, context):
            return

        current_time = datetime.now()

        # Check if the user has a username (not None)
        user_username = update.message.from_user.username
        if not user_username:
            await update.message.reply_text(translate("set_username", language_code=user_language))
            return

        # Check if the user is subscribed to the channel before processing their message
        is_subscribed = await check_subscription(update, context)
        
        if not is_subscribed:
            channel_message = translate("must_be_member", language_code=user_language).format(channel=CHANNEL_USERNAME)
            await update.message.reply_text(
                channel_message
            )
            return

        # Check if the user is trusted
        trusted_user = is_user_trusted(user_id)
        logger.info(f"User {user_id} trusted: {trusted_user}")  # Log the trusted status

        if not trusted_user:
            # Check cooldown for non-trusted users
            if user_id in user_last_submission:
                last_submission_time = user_last_submission[user_id]
                if current_time - last_submission_time < COOLDOWN_DURATION:
                    # Calculate remaining time in the cooldown period
                    time_remaining = COOLDOWN_DURATION - (current_time - last_submission_time)
                    minutes, seconds = divmod(time_remaining.total_seconds(), 60)
                    wait_message = translate("wait_before_resubmit", language_code=user_language).format(
                        minutes=int(minutes), seconds=int(seconds)
                    )
                    await update.message.reply_text(
                        wait_message
                    )
                    return

        # Validate the message content
        message_text = update.message.text.strip()
        logger.info(f"Received message: {message_text}")  # Log the received message

        is_valid, result = validate_message(message_text)
        if not is_valid:
            await update.message.reply_text(result)  # Send error message
            return

        platform_name, username_in_message, price, description = result

        # Format the username with inline quote and bold in second line
        formatted_username = f"<blockquote><code>{username_in_message}</code></blockquote>"
        formatted_message = f"{platform_name}\n{formatted_username}"

        # Add price and description if they are not empty
        if price:
            formatted_message += f"\n{price}"
        if description:
            formatted_message += f"\n{description}"

        user_username = update.message.from_user.username
        contact_button = InlineKeyboardButton(f"Contact @{user_username}", url=f"tg://user?id={update.message.from_user.id}")
        keyboard = InlineKeyboardMarkup([[contact_button]])

        # Send the valid message to the channel with the button
        sent_message = await context.bot.send_message(
            chat_id=CHANNEL_USERNAME,
            text=formatted_message,
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard  # Attach the button
        )
        sent_message_id = sent_message.message_id
        print(f"Message sent with ID: {sent_message_id}")
        await register_post(update, context, sent_message_id)
        #await register_post(update, context)
        # Log the user's last submission time if not trusted
        if not trusted_user:
            user_last_submission[user_id] = current_time
        
        await update.message.reply_text(
            translate("submission_sent", language_code=user_language).format(channel=CHANNEL_USERNAME)
        )

    except Exception as e:
        logger.error(f"Error in handle_message: {e}")
        await update.message.reply_text("An error occurred while processing your message.")
        traceback.print_exc()
async def language_selection(update: Update, context: CallbackContext):
    keyboard = [
        [
            InlineKeyboardButton("🇬🇧 English", callback_data="lang_en"),
            InlineKeyboardButton("🇸🇦 العربية", callback_data="lang_ar")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await update.message.reply_text(
            "Please choose your preferred language:", reply_markup=reply_markup
        )
    except Exception as e:
        print(e)
        traceback.print_exc()
async def language_callback(update: Update, context: CallbackContext):
    try:
        query = update.callback_query
        user_id = query.from_user.id
        selected_language = query.data.split('_')[1]  # Extract the language code

        # Check if the language is valid
        if selected_language not in ['en', 'ar']:
            raise ValueError("Invalid language code")

        # Save the user's selected language
        context.user_data['language'] = selected_language
        
        # Provide feedback based on the selected language
        if selected_language == 'en':
            message = "Language has been set to English."
        elif selected_language == 'ar':
            message = "تم تغيير اللغة إلى العربية."
        else:
            message = f"Language has been set to: {selected_language}"

        # Respond to the callback query
        await query.answer()
        await query.edit_message_text(message)  # Update the message text to reflect the new language

    except IndexError:
        # Handle cases where the callback_data format is incorrect
        
        await query.answer(text=f"This Username has been sold", show_alert=True)
        
        print("Error: Invalid language selection callback data.")
    except ValueError as e:
        # Handle invalid language code
        await query.answer()
        await query.edit_message_text(str(e))
        print(f"Error: {e}")
    except Exception as e:
        # Handle other exceptions
        print(f"Error in language callback: {e}")
        await query.answer()
        await query.edit_message_text("An error occurred while changing the language.")

def main() -> None:
    trusted_users = helpers.load_trusted_users()  # Call the function, not the set
    trusted_admins = helpers.load_trusted_admins()  # Call the function
    banned_users = helpers.load_banned_users()
    application = Application.builder().token(BOT_TOKEN).build()

    # Register the command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("commands", list_commands))
    application.add_handler(CommandHandler("istrusted", istrusted))
    application.add_handler(CommandHandler("isadmin", isadmin))
    application.add_handler(CommandHandler("ban", ban))
    application.add_handler(CommandHandler("unban", unban))
    application.add_handler(CommandHandler("addadmin", add_admin))
    application.add_handler(CommandHandler("deleteadmin", delete_admin))
    application.add_handler(CommandHandler("addtrusted", add_trusted))
    application.add_handler(CommandHandler("deletetrusted", delete_trusted))
    application.add_handler(CommandHandler("listtrusted", list_trusted))
    application.add_handler(CommandHandler("sold", mark_as_sold))
    application.add_handler(CommandHandler("whoami", whoami))
    application.add_handler(CommandHandler("listadmins", list_admins))
    application.add_handler(CommandHandler("language", language_selection))  # Added language command
    application.add_handler(CallbackQueryHandler(language_callback))


    
    # Register the message handler
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Run the bot
    application.run_polling()

if __name__ == '__main__':
    main()
